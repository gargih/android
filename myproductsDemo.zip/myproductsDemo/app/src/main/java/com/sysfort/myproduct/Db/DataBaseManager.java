package com.sysfort.myproduct.Db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.sysfort.myproduct.java.Products;

import java.util.ArrayList;
import java.util.List;

public class DataBaseManager extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "MyDBName.sqlite";
    private static String DB_PATH = "/data/data/com.sysfort.myproduct/databases/";
    public static final String USER_TABLE_NAME = "user";
    public static final String PRODUCT_TABLE_NAME = "product";
    public static final String USER_COLUMN_NAME = "username";
    public static final String USER_COLUMN_EMAIL = "email";
    public static final String CONTACTS_COLUMN_PASSWORD = "password";
    List<Products> dataList;
    public DataBaseManager(Context context) {
        super(context, DATABASE_NAME , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        Log.d("-----"," ------ onCreate user");
        sqLiteDatabase.execSQL(
                "create table IF NOT EXISTS user " +
                        "(id integer primary key AutoIncrement, username text,email text, password text)"
        );


        Log.d("-----"," ------ onCreate product");
        sqLiteDatabase.execSQL(
                "create table  IF NOT EXISTS product " +
                        "(id integer primary key AutoIncrement, productname text,price text, description text)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        Log.d("-----"," ------ onUpgrade");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS contacts");
        onCreate(sqLiteDatabase);

    }
    public boolean insertUser (String username, String email, String password) {
        Log.d("-----"," ------ insertUser");
        Log.d("-----"," ------ username="+username);
        Log.d("-----"," ------ email="+email);
        Log.d("-----"," ------ password="+password);
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("email", email);
        contentValues.put("password", password);

        db.insert("user", null, contentValues);
        return true;
    }
    public boolean insertProduct (String username, String email, String password) {
        Log.d("-----"," ------ insertUser");
        Log.d("-----"," ------ username="+username);
        Log.d("-----"," ------ email="+email);
        Log.d("-----"," ------ password="+password);
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("productname", username);
        contentValues.put("price", email);
        contentValues.put("description", password);

        db.insert("product", null, contentValues);
        return true;
    }
    public int getData(String username, String password) {
        Log.d("-----"," ------ getData");
        int retValue=0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from "+USER_TABLE_NAME+" where username= '"+username+"' and password= '"+password+"'", null );
        if(res == null){
            res.close();
        }else{
            retValue=  res.getCount();
        }
        res.close();
        return retValue;
    }

    public int numberOfRows(){
        Log.d("-----"," ------ numberOfRows");
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, USER_TABLE_NAME);
        return numRows;
    }

    public int numberOfRowsofproduct(){
        Log.d("-----"," ------ numberOfRowsofproduct");
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, PRODUCT_TABLE_NAME);
        return numRows;
    }
//



    // Getting All Products
    public List<Products> getAllDatas() {
        dataList = new ArrayList<Products>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + PRODUCT_TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Products data = new Products();
                data.setId(Integer.parseInt(cursor.getString(0)));
                data.setProduct(cursor.getString(1));
                data.setPrice(cursor.getString(2));
                data.setDescription(cursor.getString(3));
                // Adding contact to list
                dataList.add(data);
            } while (cursor.moveToNext());
        }

        // return contact list
        return dataList;
    }

}
