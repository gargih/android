package com.sysfort.myproduct.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.sysfort.myproduct.Db.DataBaseManager;
import com.sysfort.myproduct.R;

public class AddProductActivity extends AppCompatActivity {
EditText edt_productname,edt_des,edt_price;
    DataBaseManager db;
     boolean flag= false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
        Log.d("-----"," ------ AddProductActivity connected");
        db= new DataBaseManager(this);
        edt_productname=(EditText)findViewById(R.id.edt_productname);
        edt_price=(EditText)findViewById(R.id.edt_price);
        edt_des=(EditText)findViewById(R.id.edt_des);
    }
     public  void save(View view){

         if(edt_productname.getText().toString().length()==0){
             edt_productname.setError("please enter Product name");
         }
         else if(edt_price.getText().toString().length()==0){
             edt_price.setError("please enter Product Price");
         }
         else if(edt_des.getText().toString().length()==0){
             edt_des.setError("please enter discription");
         }
         else{
             flag= (boolean) db.insertProduct(edt_productname.getText().toString(),edt_price.getText().toString(),edt_des. getText().toString());
             if(flag== true){
                 Log.d("-----"," ------ flag== true");
                 Toast.makeText(this, "Successfuly Added!!!", Toast.LENGTH_SHORT).show();
                 Intent intent= new Intent(this,DashboardActivity.class);
                 startActivity(intent);
                 finish();
             }
             else {
                 Log.d("-----"," ------ flag==false");
                 Toast.makeText(this, "User Does Not Exist!!!", Toast.LENGTH_SHORT).show();
             }
         }

     }
     public  void  cancel(View view){
        Intent intent= new Intent(this,DashboardActivity.class);
        startActivity(intent);
        finish();
    }


}
