package com.sysfort.myproduct.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.sysfort.myproduct.Adapter.ListAdapter;
import com.sysfort.myproduct.Db.DataBaseManager;
import com.sysfort.myproduct.R;
import com.sysfort.myproduct.java.Products;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {
    FloatingActionButton floating_action_button, floating_action_logoutbutton;
    ListView list_products;
    DataBaseManager db;
    ArrayList<HashMap<String,String>> productlist = new ArrayList<HashMap<String,String>>();
    HashMap<String,String> productdatamap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        Log.d("-----"," ------ DashboardActivity connected");
        db= new DataBaseManager(this);
        floating_action_button=(FloatingActionButton)findViewById(R.id.floating_action_button);
        floating_action_logoutbutton=(FloatingActionButton)findViewById(R.id.floating_action_logoutbutton);
        list_products=(ListView) findViewById(R.id. list_products);
        floating_action_button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent intent= new Intent(DashboardActivity.this,AddProductActivity.class);
                startActivity(intent);
                finish();

            }

//
//
        });
        floating_action_logoutbutton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent intent= new Intent(DashboardActivity.this,LogoutActivity.class);
                startActivity(intent);
                finish();

            }

//
//
        });


        List<Products> data = db.getAllDatas();
        for (Products val : data) {

            // Writing values to map
            HashMap<String, String> map = new HashMap<String, String>();

            map.put("productname", val.getProduct());
            map.put("price", val.getPrice());
            map.put("discription", val.getDescription());


            productlist.add(map);
        }
            ListAdapter flower_Adptor = new ListAdapter(DashboardActivity.this,productlist);
        flower_Adptor.notifyDataSetChanged();
        list_products.setAdapter(flower_Adptor);
    }
}
