package com.sysfort.myproduct.java;

public class Products {
    int id;
    String product;
    String price;
    String description;

    // Empty constructor
    public Products(){

    }

    public Products(String product, String price, String description) {
        this.product = product;
        this.price = price;
        this.description = description;
    }



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


}
