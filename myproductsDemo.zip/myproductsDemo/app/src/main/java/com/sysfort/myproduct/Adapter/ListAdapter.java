package com.sysfort.myproduct.Adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.sysfort.myproduct.Activity.DashboardActivity;
import com.sysfort.myproduct.R;

import java.util.ArrayList;
import java.util.HashMap;

public class ListAdapter extends BaseAdapter {
    ArrayList<HashMap<String, String>> benefitlist = new ArrayList<HashMap<String, String>>();
    private static LayoutInflater infater = null;
    Context context;
    private int lastPosition = -1;
    public ListAdapter(DashboardActivity mainActivity, ArrayList<HashMap<String, String>> biddatalist) {

        context = mainActivity;
        infater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.benefitlist = biddatalist;

    }
    public ListAdapter(DashboardActivity mainActivity) {

        context = mainActivity;
        infater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);


    }


    @Override
    public int getCount() {

        return benefitlist.size();
//        return 5;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }
    public class Holder {
        TextView carriertxt;
        TextView carriervaluetxt,grouptxt,groupnovaluetxt,memberservicetxt,memberservicevaluetxt,carrierurltxt,carrierurlvaluetxt;

LinearLayout firstl1,firstl2,firstl3,firstl4;

    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        final Holder holder = new Holder();
        view = infater.inflate(R.layout.listviewadapter, null);

        holder.carriertxt=(TextView) view.findViewById(R.id.carriertxt);
        holder.carriervaluetxt=(TextView) view.findViewById(R.id.carriervaluetxt);
        holder.grouptxt=(TextView) view.findViewById(R.id.grouptxt);
        holder.groupnovaluetxt=(TextView) view.findViewById(R.id.groupnovaluetxt);
        holder.memberservicetxt=(TextView) view.findViewById(R.id.memberservicetxt);
        holder.memberservicevaluetxt=(TextView) view.findViewById(R.id.memberservicevaluetxt);


        holder.firstl1=(LinearLayout) view.findViewById(R.id.firstl1);
        holder.firstl2=(LinearLayout) view.findViewById(R.id.firstl2);
        holder.firstl3=(LinearLayout) view.findViewById(R.id.firstl3);


        HashMap<String, String> hashMap = benefitlist.get(i);
//        if(hashMap.get("planname").equalsIgnoreCase("0")){
//            holder.carriertxt.setVisibility(View.GONE);
//            holder.carriervaluetxt.setVisibility(View.GONE);
//            holder.firstl1.setVisibility(View.GONE);
//        }
//        else{
            holder.carriervaluetxt.setText(hashMap.get("productname"));
//        }
//
//
//        if(hashMap.get("group1").equalsIgnoreCase("0")){
//            holder.grouptxt.setVisibility(View.GONE);
//            holder.groupnovaluetxt.setVisibility(View.GONE);
//            holder.firstl2.setVisibility(View.GONE);
//        }
//        else{
            holder.groupnovaluetxt.setText(hashMap.get("price"));
//        }
//
//        if(hashMap.get("membersr").equalsIgnoreCase("0")){
//            holder.memberservicetxt.setVisibility(View.GONE);
//            holder.memberservicevaluetxt.setVisibility(View.GONE);
//            holder.firstl3.setVisibility(View.GONE);
//        }
//        else{
            holder.memberservicevaluetxt.setText(hashMap.get("discription"));
//        }
//




        Animation animation = AnimationUtils.loadAnimation(context, (i > lastPosition) ? R.anim.item_animation_from_left : R.anim.item_animation_steps);
        view.startAnimation(animation);
        lastPosition = i;


        return view;
    }
    protected void finish() {
        // TODO Auto-generated method stub
        // this.finish();
        ((DashboardActivity) context).finish();
        Log.d("-------", "-------");

    }
}
