package com.sysfort.myproduct.Activity;


import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.sysfort.myproduct.R;

import java.util.ArrayList;
import java.util.List;


public class TakePermission extends AppCompatActivity {


ImageView img_takepermisiion;


    @SuppressLint("LongLogTag")
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        //	requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_take_permission);
        Log.d("-----"," ------ TakePermisiionActivity connected");

        img_takepermisiion=(ImageView)findViewById( R.id.img_takepermisiion);

        int MyVersion = Build.VERSION.SDK_INT;


        Log.d(" if MyVersion numberOfImages1------>+","--------"+MyVersion);
        if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {
            // Log.d(" ))))))))if MyVersion numberOfImages------>+", "checkAndRequestPermissions" );
            if(checkAndRequestPermissions()) {

                startActivity(new Intent(getApplicationContext(), SplashActivity.class));

                finish();

            }else
            {
                Log.d(" if MyVersion numberOfImages2------>+","--------"+MyVersion);
                //checkAndRequestPermissions();
            }
        }
        else {
            Log.d(" if MyVersion numberOfImages3------>+","--------"+MyVersion);






            startActivity(new Intent(getApplicationContext(),
                    SplashActivity.class));

            finish();









        }

    }



    @SuppressLint("LongLogTag")
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {

                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    finish();
                    Intent intent = new Intent(this, SplashActivity.class);
                    startActivity(intent);
                    Log.d(" if MyVersion numberOfImages------>+","--------");
                    Log.d(" onRequestPermissionsResult  MyVersion numberOfImages------>+","requestCode1"+requestCode);
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                    //    Toast.makeText(TakePermission.this, "Permission denied to read your External storage", Toast.LENGTH_SHORT).show();
                } else {
                    Log.d(" onRequestPermissionsResult  MyVersion numberOfImages------>+","requestCode2"+requestCode);
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    //  Toast.makeText(TakePermission.this, "Permission denied to read your External storage", Toast.LENGTH_SHORT).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }
    @SuppressLint("LongLogTag")
    private  boolean checkAndRequestPermissions() {
        int camera = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        int storage = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
            int ReadStorage = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        //   int readphone=     ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE);
        int phone=     ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE);
        Log.d(" if MyVersion numberOfImages------>+","camera"+camera);
        Log.d(" if MyVersion numberOfImages------>+","storage"+storage);
        Log.d(" if MyVersion numberOfImages------>+", "phone" + phone);



        List<String> listPermissionsNeeded = new ArrayList<>();

        if (camera != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CAMERA);
            Log.d("55555 -------->>>>if MyVersion numberOfImages------>+", "camera" + camera);
        }
        if (storage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);

            Log.d("5555-------->>> if MyVersion numberOfImages------>+", "camera" + camera);
        }

        if (phone != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CALL_PHONE);
            Log.d("5555-------->>> if MyVersion numberOfImages------>+", "camera" + camera);

        }

        if (!listPermissionsNeeded.isEmpty())
        {
            ActivityCompat.requestPermissions(TakePermission.this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA, Manifest.permission.CALL_PHONE},
                    1);
            return false;
        }
        //  Log.d("checkAndRequestPermissions-------->>> if MyVersion numberOfImages------>+", "checkAndRequestPermissions" + checkAndRequestPermissions());


        return true;
    }



}