package com.sysfort.myproduct.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.sysfort.myproduct.Db.DataBaseManager;
import com.sysfort.myproduct.R;

public class RegistrationActivity extends AppCompatActivity {
    EditText edt_username,edt_email,edt_password,edt_cnfpassword;
    DataBaseManager db;
     boolean flag= false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        Log.d("-----"," ------ RegistrationActivity connected");
        db= new DataBaseManager(this);
        edt_email=(EditText)findViewById(R.id.edt_email);
        edt_password=(EditText)findViewById(R.id.edt_password);
        edt_username=(EditText)findViewById(R.id.edt_username);
        edt_cnfpassword=(EditText)findViewById(R.id.edt_cnfpassword);
    }
     public void save(View view){
         if(edt_username.getText().toString().length()==0){
             edt_username.setError("please enter username");
         }
         else if(edt_email.getText().toString().length()==0){
             edt_email.setError("please enter email id");
         }
         else if(edt_password.getText().toString().length()==0){
             edt_password.setError("please enter password");
         }
         else if(edt_cnfpassword.getText().toString().length()==0){
             edt_cnfpassword.setError("please renter password");
         }
         else if(!edt_cnfpassword.getText().toString().equalsIgnoreCase(edt_password.getText().toString())){
             edt_cnfpassword.setError("please renter password");
             edt_password.setError("please enter password");
         }
          else{
             flag= db.insertUser(edt_username.getText().toString(),edt_email.getText().toString(),edt_password. getText().toString());
             if(flag== true){
                 Log.d("-----"," ------ flag== true");
                 Toast.makeText(this, "Successfully Added!!!", Toast.LENGTH_SHORT).show();
                 Intent intent= new Intent(this,LoginActivity.class);
                 startActivity(intent);
                  finish();
             }
             else {
                 Log.d("-----"," ------ flag==false");
                 Toast.makeText(this, "User Does Not Exist!!!", Toast.LENGTH_SHORT).show();
             }
         }

     }
    public  void  cancel(View view){
        Intent intent= new Intent(this,LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
