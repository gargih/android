package com.sysfort.myproduct.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.sysfort.myproduct.R;

public class SplashActivity extends AppCompatActivity {
    public static final String MyPREFERENCES = "MyPrefs" ;
    SharedPreferences sharedpreferences;
    String LoginStatus;
    ImageView img_splashscren;
     TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Log.d("-----"," ------ SplashActivity connected");
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        LoginStatus  = sharedpreferences.getString("loginStatus", "0");
        Log.d("------"," ------ new LoginStatus"+LoginStatus);
        img_splashscren=(ImageView)findViewById(R.id.img_splashscren);
        txt=(TextView)findViewById(R.id.txt);
        Animation animation = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.item_animation_from_top_to_bottom);
        img_splashscren.startAnimation(animation);
        Animation animation1 = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.item_animation_steps);
        txt.startAnimation(animation1);
        final Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(4000);
//
                    if(LoginStatus.equalsIgnoreCase("1")){
                        Log.d("------"," ------ ifLoginStatus"+LoginStatus);
                        Intent intent = new Intent(SplashActivity.this, DashboardActivity.class);
                        startActivity(intent);
                        finish();}
                    else{
                        Log.d("------"," ------ else LoginStatus"+LoginStatus);
                        Intent intent = new Intent(SplashActivity.this, LoginActivity.class);

                        startActivity(intent);
                        finish();
                    }
                } catch (Exception e) {
                }

            }
        });
        thread.start();
    }
}
