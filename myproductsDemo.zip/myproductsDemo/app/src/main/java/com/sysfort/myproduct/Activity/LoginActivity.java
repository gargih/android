package com.sysfort.myproduct.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.sysfort.myproduct.Db.DataBaseManager;
import com.sysfort.myproduct.R;

public class LoginActivity extends AppCompatActivity {

    public static final String MyPREFERENCES = "MyPrefs" ;
    SharedPreferences sharedpreferences;
    EditText edt_email,edt_password;
    int flag;
      DataBaseManager db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("-----"," ------ LoginActivity connected");
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        setContentView(R.layout.activity_login);
         db= new DataBaseManager(this);
        edt_email=(EditText)findViewById(R.id.edt_email);
        edt_password=(EditText)findViewById(R.id.edt_password);


    }

    public  void login(View view){
        if(edt_email.getText().toString().length()==0){
            edt_email.setError("please enter username");
        }
        else if(edt_password.getText().toString().length()==0){
            edt_password.setError("please enter password");
        }
        else{
            flag= db.getData(edt_email.getText().toString().trim(),edt_password.getText().toString().trim());
//            if(edt_email.getText().toString().equalsIgnoreCase("admin")&&  edt_password.getText().toString().equalsIgnoreCase("admin"))
            Log.d("-----"," ------ flag"+flag);
                if(flag!=0)
            {
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putString("loginStatus", "1");
                editor.commit();
                Toast.makeText(this, "Successfully Login!!!", Toast.LENGTH_SHORT).show();
                Intent intent= new Intent(this,DashboardActivity.class);
                startActivity(intent);
                finish();
            }
            else {
                Toast.makeText(this, "User Does Not Exist!!!", Toast.LENGTH_SHORT).show();
            }
        }
    }
     public  void  registration(View view){
         Intent intent= new Intent(this,RegistrationActivity.class);
         startActivity(intent);
     }
}
